#!/usr/bin/env python3
"""Reproducible synthetic holdout: sample real references, resize, compose, JPEG.

Labels and rectangles are recorded before calling the production detector/matcher.
No generated crop is added to the reference catalog.
"""
import argparse
import json
from pathlib import Path
import random
import sys
import cv2
import numpy as np
from deck_recognizer.catalog import discover_data, load_metadata
from deck_recognizer.cli import main as analyze
from deck_recognizer.images import image_files, read_image


def iou(a, b):
    x, y, w, h = a
    xx, yy, ww, hh = b
    intersection = max(0, min(x+w, xx+ww)-max(x, xx))*max(0, min(y+h, yy+hh)-max(y, yy))
    return intersection / max(1, w*h+ww*hh-intersection)


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data")
    p.add_argument("--output", required=True, help="New benchmark directory")
    p.add_argument("--cache", default=str(Path(__file__).resolve().parent / "cache"))
    p.add_argument("--count", type=int, default=40)
    p.add_argument("--width", type=int, default=76)
    p.add_argument("--jpeg-quality", type=int, default=75)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    if args.count < 1 or args.width < 24 or not 1 <= args.jpeg_quality <= 100:
        p.error("count>=1, width>=24 and JPEG quality 1..100 are required")
    root = discover_data(args.data, Path(__file__).resolve().parent)
    out = Path(args.output).resolve()
    if out.exists() and any(out.iterdir()):
        p.error("Use a new, empty output directory")
    if out == root or root in out.parents:
        p.error("Benchmark output must be outside dm_data")
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    files = image_files(root)
    metadata, _ = load_metadata(root)
    # Sample 75% unique files plus repeated displayed copies, then shuffle their positions.
    selected = rng.sample(files, min(len(files), max(1, int(args.count*.75))))
    selected += rng.choices(selected, k=args.count-len(selected))
    rng.shuffle(selected)
    columns = min(args.count, 8)
    rows = (args.count+columns-1)//columns
    w, h, gx, gy, padding, heading = args.width, round(args.width/0.70), 7, 9, 25, 50
    canvas = np.full((heading+rows*(h+gy)+padding, 2*padding+columns*(w+gx), 3), 255, np.uint8)
    cv2.putText(canvas, "SYNTHETIC DECK / SEED {}".format(args.seed), (padding, 25),
                cv2.FONT_HERSHEY_SIMPLEX, .55, (30, 30, 30), 1)
    truth = []
    for i, file in enumerate(selected):
        x, y = padding+i%columns*(w+gx), heading+i//columns*(h+gy)
        canvas[y:y+h, x:x+w] = cv2.resize(read_image(file), (w, h), interpolation=cv2.INTER_AREA)
        relative = file.relative_to(root).as_posix()
        info = metadata.get(relative, metadata.get(file.name, {}))
        card_id = info.get("card_id", Path(relative).with_suffix("").as_posix())
        name = info.get("card_name", "")
        truth.append({"file": relative, "bbox": [x, y, w, h],
                      "identity_id": info.get("identity_id", "name:"+name if name else card_id)})
    cv2.imencode(".jpg", canvas, [cv2.IMWRITE_JPEG_QUALITY, args.jpeg_quality])[1].tofile(str(out / "deck.jpg"))
    (out / "ground_truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2), encoding="utf-8")
    code = analyze(["--image", str(out/"deck.jpg"), "--data", str(root), "--cache", args.cache,
                    "--output", str(out/"recognition"), "--expected-count", str(args.count)])
    if code:
        return code
    result = json.loads((out/"recognition"/"results.json").read_text(encoding="utf-8"))
    detections = result["cards"]
    edges = sorted([(iou(t["bbox"], d["bbox"]), ti, di) for ti, t in enumerate(truth)
                    for di, d in enumerate(detections)], reverse=True)
    used_truth, used_detect, paired = set(), set(), []
    for overlap, ti, di in edges:
        if overlap >= .75 and ti not in used_truth and di not in used_detect:
            paired.append((truth[ti], detections[di], overlap))
            used_truth.add(ti)
            used_detect.add(di)
    strict = sum(t["file"] == d["candidates"][0]["file"] for t, d, _ in paired)
    top_k = sum(any(t["file"] == c["file"] for c in d["candidates"]) for t, d, _ in paired)
    identity = sum(t["identity_id"] == d["candidates"][0]["identity_id"] for t, d, _ in paired)
    accepted = [d for d in detections if d["status"] == "matched"]
    correct_accepted = sum(t["file"] == d["final_file"] for t, d, _ in paired if d["status"] == "matched")
    metrics = {"seed": args.seed, "thumbnail_width": w, "jpeg_quality": args.jpeg_quality,
               "reference_count": result["reference_count"], "truth_count": len(truth),
               "detected_count": len(detections), "paired_at_iou_075": len(paired),
               "detection_recall": len(paired)/len(truth),
               "detection_precision": len(paired)/len(detections) if detections else None,
               "end_to_end_top1_file_accuracy": strict/len(truth),
               "end_to_end_top5_file_recall": top_k/len(truth),
               "end_to_end_top1_identity_accuracy": identity/len(truth),
               "accepted_file_precision": correct_accepted/len(accepted) if accepted else None,
               "accepted_file_coverage": len(accepted)/len(truth),
               "status_counts": result["summary"]["status_counts"],
               "note": "Synthetic resize/JPEG benchmark; not an accuracy estimate for arbitrary websites. Identical reference files can reduce strict filename accuracy."}
    (out/"metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
