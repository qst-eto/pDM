import argparse
import json
from datetime import datetime
from pathlib import Path
import platform
import sys
import time
import cv2
import numpy as np
from .catalog import discover_data
from .detection import detect
from .images import read_image, write_image
from .index import build_index
from .matching import match_card
from .reporting import summarize, save_report


def numbers(value, count, kind=int):
    try:
        parsed = tuple(kind(v) for v in value.lower().replace("x", ",").split(","))
    except ValueError:
        raise argparse.ArgumentTypeError("Expected comma-separated numbers")
    if len(parsed) != count:
        raise argparse.ArgumentTypeError("Expected {} values".format(count))
    return parsed


def main(argv=None):
    project = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description="Recognize website deck-list screenshots (no training).")
    parser.add_argument("--image", default=str(project / "examples" / "image.png"))
    parser.add_argument("--data", help="Reference image directory; otherwise auto-discover dm_data")
    parser.add_argument("--output", help="New output directory; an existing nonempty directory is refused")
    parser.add_argument("--cache", default=str(project / "cache"))
    parser.add_argument("--rebuild-index", action="store_true")
    parser.add_argument("--detect-only", action="store_true")
    parser.add_argument("--mode", choices=("auto", "grid", "contours"), default="auto")
    parser.add_argument("--roi", type=lambda v: numbers(v, 4), help="x,y,width,height in original image")
    parser.add_argument("--grid", type=lambda v: numbers(v, 2), help="ROWS,COLS, e.g. 5,8; use --roi for the card area")
    parser.add_argument("--gap", type=lambda v: numbers(v, 2), default=(0, 0), help="horizontal,vertical gutter pixels")
    parser.add_argument("--aspect", type=lambda v: numbers(v, 2, float), default=(.58, .82))
    parser.add_argument("--min-width", type=int, default=24)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--shortlist", type=int, default=30)
    parser.add_argument("--min-score", type=float, default=.76)
    parser.add_argument("--min-margin", type=float, default=.025)
    parser.add_argument("--expected-count", type=int, help="Warn on count mismatch; never force detection count")
    args = parser.parse_args(argv)
    if min(args.top_k, args.shortlist, args.min_width) < 1:
        parser.error("top-k, shortlist, min-width must be positive")
    if not (0 <= args.min_score <= 1 and 0 <= args.min_margin <= 1):
        parser.error("min-score/min-margin must be in [0,1]")
    if not 0 < args.aspect[0] <= args.aspect[1]:
        parser.error("Invalid aspect range")
    if args.grid and min(args.grid) < 1:
        parser.error("Grid rows and columns must be positive")
    started = time.perf_counter()
    try:
        cv2.setNumThreads(1)
        image_path = Path(args.image).expanduser().resolve()
        image = read_image(image_path)
        index = None
        if not args.detect_only:
            root = discover_data(args.data, project)
            print("Reference images: {}".format(root), flush=True)
            index = build_index(root, args.cache, args.rebuild_index)
            print("Index: {} usable images ({})".format(len(index["entries"]),
                  "cached" if index["cache_hit"] else "built"), flush=True)
        detect_started = time.perf_counter()
        boxes, detection = detect(image, args.mode, args.roi, args.grid, args.gap,
                                  args.min_width, args.aspect)
        detection["seconds"] = round(time.perf_counter()-detect_started, 4)
        if not boxes:
            raise ValueError("No card rectangles found. Try --roi, --mode contours, or --grid ROWS,COLS --gap X,Y.")
        out = Path(args.output).expanduser().resolve() if args.output else (
            project / "runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
        if out.exists() and any(out.iterdir()):
            raise ValueError("Output directory is not empty; choose a new --output: {}".format(out))
        if index and (out == root or root in out.parents):
            raise ValueError("Output must be outside dm_data to keep crops out of the reference index.")
        out.mkdir(parents=True, exist_ok=True)
        cards = []
        for position, box in enumerate(boxes, 1):
            x, y, w, h = box
            crop = image[y:y+h, x:x+w]
            crop_path = "crops/{:03d}.png".format(position)
            write_image(out / crop_path, crop)
            matched = match_card(crop, index, args.top_k, args.shortlist, args.min_score,
                                 args.min_margin) if index else {"status": "not_run"}
            cards.append(dict(matched, position=position, bbox=list(box), crop=crop_path))
            if position % 10 == 0:
                print("Cards: {}/{}".format(position, len(boxes)), flush=True)
        warnings = list(index["warnings"]) if index else []
        if args.expected_count is not None and args.expected_count != len(cards):
            warnings.append("Expected {} cards, detected {}".format(args.expected_count, len(cards)))
        if index and index["skipped_files"]:
            warnings.append("{} reference files were skipped; see index.skipped_files".format(len(index["skipped_files"])))
        summary = summarize(cards)
        if any(c["status"] in ("unknown", "ambiguous") for c in cards):
            warnings.append("Some image identities are unresolved. Review crops and candidates; the catalog may lack the exact printing.")
        result = {"schema_version": 1, "input": str(image_path),
                  "image_size": {"width": image.shape[1], "height": image.shape[0]},
                  "settings": vars(args), "detection": detection,
                  "index": {key: index[key] for key in ("reference_root", "fingerprint", "cache_hit",
                             "index_seconds", "skipped_files")} if index else None,
                  "reference_count": len(index["entries"]) if index else 0,
                  "cards": cards, "summary": summary, "warnings": warnings,
                  "score_note": "Heuristic similarity in [0,1], NOT calibrated probability. Margins are within the reranked shortlist.",
                  "environment": {"python": platform.python_version(), "opencv": cv2.__version__, "numpy": np.__version__},
                  "analysis_seconds": round(time.perf_counter()-started, 4)}
        save_report(out, result, image)
        print(json.dumps({"output": str(out), "detected_count": len(cards),
                          "status_counts": summary["status_counts"],
                          "identity_status_counts": summary["identity_status_counts"],
                          "analysis_seconds": result["analysis_seconds"]}, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, cv2.error) as exc:
        print("ERROR: {}".format(exc), file=sys.stderr)
        return 2
