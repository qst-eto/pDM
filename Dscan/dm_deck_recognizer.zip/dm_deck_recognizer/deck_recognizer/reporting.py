import base64
import csv
import html
import json
from collections import Counter
from pathlib import Path
import cv2
from .images import read_image, write_image


def write_csv(path, rows, fields):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            # Excel must display imported filenames/names as text, not execute formulas.
            writer.writerow({key: "'" + value if isinstance(value, str) and
                             value.startswith(("=", "+", "-", "@", "\t", "\r")) else value
                             for key, value in row.items()})


def summarize(cards):
    by_file, by_identity = {}, {}
    for card in cards:
        if not card.get("candidates"):
            continue
        first = card["candidates"][0]
        for target, key, status in ((by_file, first["file"], card["status"]),
                                    (by_identity, first["identity_id"], card["identity_status"])):
            if key not in target:
                target[key] = {"card_id": first["card_id"], "file": first["file"],
                               "identity_id": first["identity_id"], "card_name": first["card_name"],
                               "confirmed_count": 0, "ambiguous_count": 0,
                               "unknown_top1_count": 0, "displayed_count": 0}
            field = {"matched": "confirmed_count", "ambiguous": "ambiguous_count",
                     "unknown": "unknown_top1_count"}[status]
            target[key][field] += 1
            target[key]["displayed_count"] += 1
    return {"by_file": list(by_file.values()), "by_identity": list(by_identity.values()),
            "status_counts": dict(Counter(c["status"] for c in cards)),
            "identity_status_counts": dict(Counter(c.get("identity_status", "not_run") for c in cards)),
            "detected_count": len(cards),
            "counting_unit": "one visible thumbnail; numeric quantity badges are not read"}


def save_report(out, result, original):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    rows, candidates = [], []
    overlay = original.copy()
    for card in result["cards"]:
        x, y, w, h = card["bbox"]
        status = card["status"]
        color = {"matched": (65, 190, 30), "ambiguous": (0, 180, 255),
                 "unknown": (40, 40, 230)}.get(status, (255, 120, 30))
        cv2.rectangle(overlay, (x, y), (x+w-1, y+h-1), color, 2)
        cv2.rectangle(overlay, (x, y), (x+31, y+17), color, -1)
        cv2.putText(overlay, str(card["position"]), (x+2, y+13), cv2.FONT_HERSHEY_SIMPLEX,
                    .42, (255, 255, 255), 1, cv2.LINE_AA)
        first = card.get("candidates", [{}])[0]
        rows.append(dict(card, x=x, y=y, width=w, height=h,
                         top1_card_id=first.get("card_id"), top1_file=first.get("file"),
                         top1_card_name=first.get("card_name")))
        candidates.extend(dict(c, position=card["position"], rank=i+1)
                          for i, c in enumerate(card.get("candidates", [])))
    write_image(out / "annotated.png", overlay)
    write_csv(out / "cards.csv", rows, ["position", "x", "y", "width", "height", "status",
              "identity_status", "final_card_id", "final_file", "final_card_name", "final_identity_id",
              "best_score", "margin", "identity_margin", "top1_card_id", "top1_file", "top1_card_name", "crop"])
    write_csv(out / "candidates.csv", candidates, ["position", "rank", "card_id", "file", "card_name",
              "identity_id", "score", "phash_distance", "hash_similarity", "color_similarity",
              "histogram_similarity", "ssim", "query_variant"])
    fields = ["card_id", "file", "identity_id", "card_name", "confirmed_count", "ambiguous_count",
              "unknown_top1_count", "displayed_count"]
    write_csv(out / "summary_files.csv", result["summary"]["by_file"], fields)
    write_csv(out / "summary_cards.csv", result["summary"]["by_identity"], fields)
    _html_report(out, result)


def _html_report(out, result):
    esc = lambda value: html.escape(str(value), quote=True)
    previews = {}
    def preview(relative):
        if relative not in previews:
            try:
                image = read_image(Path(result["index"]["reference_root"]) / relative)
                image = cv2.resize(image, (96, 136), interpolation=cv2.INTER_AREA)
                ok, encoded = cv2.imencode(".jpg", image)
                previews[relative] = "data:image/jpeg;base64," + base64.b64encode(encoded).decode("ascii") if ok else ""
            except (OSError, ValueError):
                previews[relative] = ""
        return previews[relative]
    parts = ['<!doctype html><html lang="ja"><meta charset="utf-8"><title>デッキ画像 認識結果</title>',
             '<style>body{font-family:system-ui,sans-serif;max-width:1300px;margin:32px auto;padding:0 20px;background:#f5f7fa;color:#183040}h1{font-size:26px}a{color:#145caa}.card{background:white;padding:16px;margin:12px 0;border-radius:10px}.candidates{display:flex;gap:16px;overflow:auto}.item{min-width:145px;max-width:220px;font-size:12px;overflow-wrap:anywhere}.item img{height:180px;max-width:140px;object-fit:contain}.matched{color:#277a23}.unknown{color:#bb2828}.ambiguous{color:#936200}small{display:block}table{border-collapse:collapse}td,th{padding:8px;border-bottom:1px solid #ccc;text-align:left}</style>',
             '<h1>デッキ画像 認識結果</h1>',
             '<p>検出 {} 枚 · 方式 {} · 類似度は正解確率ではありません。</p>'.format(
                 len(result["cards"]), esc(result["detection"]["method"])),
             '<p>matched＝閾値を満たす一致、ambiguous＝候補が近く保留、unknown＝一致不足。'
             'カード名の判定と画像版の判定は別です。サムネイル1個を1枚として数えます。</p>',
             '<p><a href="results.json">JSON</a> · <a href="cards.csv">カード別CSV</a> · '
             '<a href="candidates.csv">上位候補CSV</a> · <a href="summary_cards.csv">枚数集計CSV</a></p>',
             '<details><summary>検出位置を見る</summary><img src="annotated.png" style="max-width:100%"></details>']
    for warning in result["warnings"]:
        parts.append('<p class="ambiguous">{}</p>'.format(esc(warning)))
    for card in result["cards"]:
        parts.append('<section class="card"><b>#{}</b> <strong class="{}">{}</strong> '
                     'カード名判定: {}<div class="candidates"><div class="item">入力<br>'
                     '<img src="{}"></div>'.format(card["position"], esc(card["status"]),
                      esc(card["status"]), esc(card.get("identity_status", "not_run")), esc(card["crop"])))
        for rank, candidate in enumerate(card.get("candidates", []), 1):
            parts.append('<div class="item">候補 {} · {:.3f}<br><img src="{}"><br><b>{}</b>'
                         '<small>{}</small><small>pHash距離 {} / SSIM {:.3f}</small></div>'.format(
                         rank, candidate["score"], preview(candidate["file"]), esc(candidate["card_name"]),
                         esc(candidate["file"]), candidate["phash_distance"], candidate["ssim"]))
        parts.append('</div></section>')
    parts.append('</html>')
    (out / "report.html").write_text("\n".join(parts), encoding="utf-8")
