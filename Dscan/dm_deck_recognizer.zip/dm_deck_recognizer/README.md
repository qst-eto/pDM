# デュエル・マスターズ デッキ画像認識

Webサイト等のデッキリスト画像から、カード領域を切り出してローカルの `dm_data` 内の参照画像を検索する初期版です。学習・GPU・画像の外部送信は不要です。リアルタイムカメラ、OCR、傾いた実物カードは対象外です。

## このPCですぐ実行

このフォルダで、次の1コマンドを実行します。添付画像の解析まで動作確認済みです。

```powershell
.\run_example.cmd
```

インデックスの作成／再利用 → 領域検出 → 照合 → 枚数集計 → 出力を実行します。完了時に出力先を表示します。`runs/<日時>/report.html` をブラウザーで開くと、切り出し画像と上位候補を並べて確認できます。

このPC専用ランチャーは、作成済みのプロジェクト内 `.venv` を使います。予備として作業用 `../../work/.venv` も探します。参照先は発見した `C:\Users\EtoHayato\Desktop\Dscan\dm_data` です。元の画像・DBは読み取り専用で利用します。

別画像を解析する場合も、以下を1コマンドで実行できます。ランチャーでは末尾の指定が優先されます。

```powershell
.\run_example.cmd --image "C:\path\to\deck.png"
```

## 他の環境へのセットアップ

推奨は CPython 3.9〜3.12。Python 3.8向けの依存関係も分岐しています。初回だけインターネット接続が必要です。

```bash
python run.py --setup --data "/path/to/dm_data" --image "examples/image.png"
```

`--setup` はこのフォルダの `.venv` に依存関係をインストールし、そのPythonで解析まで続けます。既存のシステム環境へパッケージを追加しません。

2回目以降：

```powershell
# Windows
.venv\Scripts\python.exe run.py --data "C:\path\to\dm_data" --image "examples\image.png"
```

```bash
# macOS / Linux
.venv/bin/python run.py --data /path/to/dm_data --image examples/image.png
```

標準の手動セットアップにも対応します。

```bash
python -m venv .venv
# 仮想環境を有効化するか、その中のPythonを指定して以下を実行
python -m pip install -r requirements.txt
python run.py --data /path/to/dm_data --image examples/image.png
```

依存関係は NumPy と `opencv-python-headless` の2つです。pHashはOpenCVのDCTで実装しているため、ImageHash、SciPy、scikit-image、opencv-contribは不要です。同じ仮想環境へ複数種類のOpenCVを入れないでください。

## 実データと添付画像

今回、以下の2か所に `dm_data` を発見しました。どちらもJPGが2,462枚あり、ファイル名・サイズ一覧が一致しました。DBと確認したサンプル画像のSHA-256も一致しましたが、全画像の内容ハッシュを比較したわけではありません。

- `C:\Users\EtoHayato\Desktop\Dscan\dm_data`
- `C:\Users\EtoHayato\Desktop\projectDM\pDM\dm_data`

解析には前者を明示指定しています。フォルダ直下に画像、`Duelmasters.db`、既存の取得スクリプトがあります。取得スクリプトは実行しません。DBの `cardlist(cardname, picturl, imagefile)` から画像とカード名の対応を読み取ります。1画像に複数のカード名が対応する場合は名前を連結します。

元会話の `/mnt/data/image.png` はWindows上には存在しませんでしたが、元会話の添付ファイルを取得し、内容をそのまま `examples/image.png` に保存しています。

最終の添付画像テストは `runs/attachment_verified/` にあります。

| 確認項目 | 結果 |
|---|---:|
| 参照画像 | 2,462枚、読み込み失敗0枚 |
| 自動検出 | 8列×5行、40枚 |
| 画像ファイルまで閾値を満たす一致 | 12枚 |
| 類似した画像版が複数あるため保留 | 10枚 |
| 一致スコア不足 | 18枚 |
| カード名単位で閾値を満たす一致 | 22枚 |

これらは判定ステータスの件数で、正解率ではありません。添付画像の全カードに対する独立した正解ファイル一覧はありません。手元の参照画像には2025〜2026年のファイル接頭辞があり、デッキ内の同じ絵柄が収録されていない場合があります。同一カード名でも絵柄や箔加工・印刷が違う画像は、学習不要の画像照合では一致しないことがあります。保留・不一致を確認して参照画像を補う用途にも使えます。

## ディレクトリ構成

```text
dm_deck_recognizer/
  run.py                 # CLI入口、--setupで環境作成も可能
  run_example.cmd        # このPCで添付画像を実行するランチャー
  evaluate.py            # 正解が分かる合成デッキによる評価
  requirements.txt
  deck_recognizer/        # 検出・特徴量・索引・照合・出力
  tests/                 # 自動テスト
  dm_data/               # 任意：ここへ参照画像を配置
    metadata.csv         # 任意：ID・名前・集計単位の上書き
    set_A/card001.jpg    # サブフォルダも対応
  examples/image.png     # 元会話の添付画像
  cache/index_*.npz      # 自動生成される索引
  runs/<日時>/           # 実行ごとの出力
```

参照画像はJPG/JPEG/PNG/WebP/BMP/TIF/TIFFを再帰的に探索します。日本語パスと透明PNGに対応します。非画像ファイルを無視し、壊れた画像は警告とともにスキップします。

参照先の探索順は `--data` → 環境変数 `DM_DATA_DIR` → カレント／プロジェクト直下の `dm_data` → 周辺とDesktop/Documents/Downloadsの深さ3までです。複数の候補が見つかる場合は、意図しないデータを選ばないよう候補を表示して停止します。`--data` で指定してください。何もない場合は同梱の空の `dm_data` に画像を配置します。

## 処理方式

1. **高速グリッド検出**：複数の背景・輝度マスクで連結成分を抽出し、カードに近い縦横比と大きさ、等間隔の行列配置を確認します。安定した行列から共通の切り出し位置を推定します。8列や40枚は固定していません。末尾の空きセルは画像内容で除外します。
2. **輪郭へのフォールバック**：グリッドが成立しなければ、二値画像・Cannyエッジの輪郭、矩形度、縦横比、サイズの繰り返しを使います。重複矩形を除外します。配置が明らかな場合は `--roi --grid --gap` で直接分割できます。
3. **参照索引**：96×136に正規化し、全体とイラスト寄りの領域から256ビットDCT pHash、HSVヒストグラム、8×8のLab色配置、SSIM用グレースケール画像を保存します。全体のハッシュを主に使い、ツインパクト等にも対応できるよう絵柄領域への依存を小さくしています。
4. **候補検索**：全体80%＋絵柄20%のハッシュ類似度を用い、`0.65×hash + 0.15×HSV + 0.20×Lab` で上位30件を選びます。
5. **再ランキング**：`0.30×hash + 0.10×HSV + 0.15×Lab + 0.45×SSIM`。SSIMは両画像を64×90へ縮小し、11×11・σ=1.5の窓で比較します。切り出し境界の小さな誤差に対して、入力の外周を0%、1.5%、3%除いた3種類を比較します。
6. **判定・集計**：絶対スコアと2位との差で判定します。画像ファイル単位と、メタデータで束ねた同一カード単位の集計を保存します。

スコアは0〜1の経験的な類似度で、正解確率ではありません。pHashのDC成分を固定しているため可変ビット数は255、出力のpHash距離は0〜255です。SSIM自体の負の値は、合成スコアでは0へ丸めます。

## 判定・出力の読み方

初期閾値は `--min-score 0.76 --min-margin 0.025` です。サイト別の正解データで調整してください。

- `matched`：スコアと差分の条件を満たす。画像版では `final_card_id` / `final_file` が入ります。
- `ambiguous`：スコアは足りるが候補が近い。最終ID／ファイルは空欄で、候補だけ残します。
- `unknown`：絶対スコア不足。最終ID／ファイルは空欄です。未登録、別絵柄、切り出し失敗などを確認します。

`identity_status` はカード名・明示した集計ID単位の判定です。画像版が保留でも、上位の画像が同じカード名に対応するなら名前単位で `matched` になることがあります。`final_identity_id` と `final_card_name` に保存します。メタデータの誤りも結果へ影響します。

上位候補が1件だけならmarginはnullです。カード名の異なる候補が再ランキング範囲にいなければidentity_marginはnullで、絶対閾値のみで判定します。marginは全参照に対する保証ではなく上位候補内の差です。

| ファイル | 内容 |
|---|---|
| `report.html` | 入力と上位候補画像を並べたローカルレポート |
| `annotated.png` | 元画像へ検出枠・位置番号を描画 |
| `crops/001.png` 等 | カードごとの原解像度切り出し |
| `results.json` | 設定、環境、索引情報、矩形、全認識結果、候補、集計、警告 |
| `cards.csv` | 1領域1行。最終ID、ファイル、候補1位、類似度など |
| `candidates.csv` | 各領域のTop-Kとスコア内訳 |
| `summary_files.csv` | 画像ファイル単位の枚数 |
| `summary_cards.csv` | カード名／集計ID単位の枚数 |

CSVはExcelで読みやすいUTF-8 BOM付きです。JSONの候補IDは元の値を保ち、CSVで数式に見える名前はテキストとして保存します。矩形は元画像座標で `x,y,width,height`、右端・下端は含みません。並び順は上から下、各行では左から右です。

集計は `confirmed_count`（一致）、`ambiguous_count`（候補保留）、`unknown_top1_count`（不一致の仮1位）、`displayed_count`（これらの合計）に分かれます。**unknown_top1_count を実際のカード枚数として扱わないでください。** `summary_cards.csv` の `file` は代表候補で、画像版ごとの内訳は `summary_files.csv` を使います。

**サムネイル1個を1枚として数えます。** 今回の画像のように40枚を個別表示する形式が対象です。1画像の脇に「×4」と書く形式の数量は読みません。重なり、回転、強い装飾、接触した不規則配置、複数サイズの独立グリッドなどは検出漏れや誤検出の可能性があります。検出はヒューリスティックなので、`annotated.png` と期待枚数で確認してください。

## 手動指定・調整

```bash
# 自動グリッドを使わず輪郭検出
python run.py --data /path/to/dm_data --image deck.png --mode contours

# 領域を限定したうえで自動検出
python run.py --data /path/to/dm_data --image deck.png --roi 90,252,659,606

# 添付画像に対して5行8列、横4px・縦約4pxの隙間を指定する例
# 手動値は調整用。通常の実行ではこれらの座標は不要
python run.py --data /path/to/dm_data --image examples/image.png --roi 98,263,644,584 --grid 5,8 --gap 4,4

# 検出だけ確認。参照画像なしで実行可能
python run.py --image examples/image.png --detect-only

# 上位候補を増やす、期待枚数を確認、索引を強制作り直す
python run.py --data /path/to/dm_data --image deck.png --top-k 10 --shortlist 60 --expected-count 40 --rebuild-index
```

`--expected-count` は不一致を警告するだけで、検出枚数を無理に合わせません。`--output` に指定するフォルダは空か未作成にしてください。再実行時に古い切り出しと混ざることを防いでいます。既定では毎回新しい日時フォルダを作ります。

索引は参照ルート、相対パス、サイズ、更新時刻、メタデータ、特徴量バージョンで更新を検知します。追加・削除・更新で自動的に新しい索引を作ります。同じサイズ・更新時刻を維持した画像差し替えには `--rebuild-index` を使ってください。古い `cache/index_*.npz` は自動削除しないため、不要になった索引は手動で整理できます。

## 任意のID・カード名マッピング

DBがなくても画像ファイルだけで動きます。既定の `card_id` は拡張子を除いた相対パスです。例えば `set_A/card001.jpg` は `set_A/card001` となり、サブフォルダ間の同名画像を区別します。

`dm_data/metadata.csv` を置けば、DBの対応を上書きできます。

```csv
file,card_id,card_name,identity_id
set_A/card001.jpg,set_A-card001,カード名A,card-A
set_B/card050.jpg,set_B-card050,カード名A,card-A
```

`identity_id` を同じにすると、別版の画像を同じカードの枚数として集計します。ファイル列はdm_dataからの相対パスで `/` 区切りです。指定しない場合は、名前があればカード名、名前がなければカードIDを集計キーにします。

## 検証・精度評価

```bash
python -m unittest discover -s tests -v
python evaluate.py --data /path/to/dm_data --output runs/benchmark --count 40 --width 76 --jpeg-quality 75 --seed 42
```

評価スクリプトは実際の参照画像をランダムに選んで縮小・JPEG圧縮したデッキを作り、作成時に記録した正解矩形・ファイル名で評価します。`ground_truth.json`、検出IoU、Top-1/Top-5、カード名単位の精度、確定した判定の精度・カバー率を保存します。未検出もエンドツーエンドの分母に含めます。同一画像が別ファイル名で複数存在すると、厳密なファイル名のTop-1は下がることがあります。

合成評価は縮小・圧縮への動作確認であり、任意のWebサイトや別絵柄の認識精度を保証しません。実画像の評価には、正解カードIDと正解切り出しを別途用意し、切り出し漏れと照合ミスを分けて数える必要があります。

実行検証はWindows / CPython 3.12.14 / NumPy 1.26.4 / OpenCV 4.10.0で行いました。3.8の構文互換性をチェックし、依存関係をNumPy 1.24.4へ分岐していますが、3.8実機では未実行です。3.13以降用の依存指定はありますが、この環境では未検証です。

今回の合成評価（seed=42、40枚、幅76px、JPEG品質75）は `runs/benchmark_seed42/metrics.json` に保存しています。検出40/40、厳密なファイル名Top-1は38/40、Top-5は40/40、カード名単位のTop-1は40/40、画像ファイルまで確定した33枚の正解は33/33でした。添付画像での正解率とは別の値です。

## 実装時に確認した一次資料

- [OpenCV: 輪郭・連結成分・矩形](https://docs.opencv.org/4.x/d3/dc0/group__imgproc__shape.html)
- [OpenCV: DCTなどの配列演算](https://docs.opencv.org/4.x/d2/de8/group__core__array.html)
- [SSIM原論文（Wangほか）](https://ece.uwaterloo.ca/~z70wang/publications/ssim.pdf)
- [opencv-python-headless 4.10.0.84](https://pypi.org/project/opencv-python-headless/4.10.0.84/)
- [NumPy 1.24.4](https://pypi.org/project/numpy/1.24.4/)
