@echo off
setlocal
set "DECK_PYTHON=%~dp0.venv\Scripts\python.exe"
if not exist "%DECK_PYTHON%" set "DECK_PYTHON=%~dp0..\..\work\.venv\Scripts\python.exe"
if not exist "%DECK_PYTHON%" (
  echo Python environment not found. Run: python run.py --setup --data PATH_TO_DM_DATA
  exit /b 2
)
"%DECK_PYTHON%" "%~dp0run.py" --image "%~dp0examples\image.png" --data "C:\Users\EtoHayato\Desktop\Dscan\dm_data" --expected-count 40 %*
exit /b %ERRORLEVEL%
