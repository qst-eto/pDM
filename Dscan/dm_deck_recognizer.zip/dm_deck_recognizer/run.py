#!/usr/bin/env python3
"""One command: optional isolated install, index build/update, then deck analysis."""
import os
from pathlib import Path
import subprocess
import sys


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    if sys.version_info < (3, 8):
        print("Python 3.8 or newer is required.", file=sys.stderr)
        return 2
    project = Path(__file__).resolve().parent
    args = sys.argv[1:]
    if "--setup" in args:
        args.remove("--setup")
        import venv
        directory = project / ".venv"
        executable = directory / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        if not executable.is_file():
            venv.EnvBuilder(with_pip=True).create(str(directory))
        subprocess.check_call([str(executable), "-m", "pip", "install", "-r", str(project / "requirements.txt")])
        return subprocess.call([str(executable), str(project / "run.py")] + args)
    try:
        from deck_recognizer.cli import main as cli_main
    except ImportError as exc:
        print("Missing dependency: {}\nRun: python run.py --setup --image YOUR_IMAGE".format(exc), file=sys.stderr)
        return 2
    return cli_main(args)


if __name__ == "__main__":
    sys.exit(main())
