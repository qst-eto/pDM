"""End-to-end fixtures are generated from independent known layouts and identities."""
import json
from pathlib import Path
import tempfile
import unittest
import cv2
import numpy as np
from deck_recognizer.cli import main
from deck_recognizer.detection import detect
from deck_recognizer.images import read_image, write_image
from deck_recognizer.index import build_index
from deck_recognizer.matching import match_card


def card_image(seed):
    rng = np.random.RandomState(seed)
    image = np.full((196, 140, 3), 18, np.uint8)
    image[5:-5, 5:-5] = rng.randint(50, 230, 3)
    for _ in range(18):
        x, y = rng.randint(12, 125), rng.randint(15, 178)
        cv2.circle(image, (x, y), int(rng.randint(5, 22)),
                   tuple(int(v) for v in rng.randint(0, 255, 3)), -1)
    cv2.rectangle(image, (8, 141), (131, 184), (225, 225, 220), -1)
    cv2.putText(image, str(seed), (15, 170), cv2.FONT_HERSHEY_SIMPLEX, .8, (10, 10, 10), 2)
    return image


def make_deck(cards, ids, columns=4, background=255, gap=(8, 10), irregular=False):
    rows = (len(ids) + columns - 1) // columns
    result = np.full((100 + rows*(98+gap[1]), 100 + columns*(70+gap[0]), 3), background, np.uint8)
    boxes = []
    for i, identity in enumerate(ids):
        x = 32 + i % columns*(70+gap[0])
        y = 38 + i // columns*(98+gap[1])
        if irregular:
            x += [0, 8, 0, 13][i % 4]
            y += [0, 12, 4, 15][i % 4]
        result[y:y+98, x:x+70] = cv2.resize(cards[identity], (70, 98), interpolation=cv2.INTER_AREA)
        boxes.append((x, y, 70, 98))
    return result, boxes


def iou(a, b):
    x, y, w, h = a
    xx, yy, ww, hh = b
    intersection = max(0, min(x+w, xx+ww)-max(x, xx))*max(0, min(y+h, yy+hh)-max(y, yy))
    return intersection / (w*h+ww*hh-intersection)


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.data = self.root / "参照画像"
        self.data.mkdir()
        self.cards = [card_image(i) for i in range(8)]
        for i, image in enumerate(self.cards):
            write_image(self.data / ("card_{}.png".format(i)), image)

    def tearDown(self):
        self.temporary.cleanup()

    def test_auto_grid_partial_row_and_dark_background(self):
        for background in (255, 0):
            with self.subTest(background=background):
                deck, expected = make_deck(self.cards, [0, 1, 2, 3, 1, 4, 5], background=background)
                actual, details = detect(deck)
                self.assertEqual(details["method"], "auto_grid")
                self.assertEqual(len(actual), len(expected))
                self.assertTrue(all(iou(a, b) > .80 for a, b in zip(actual, expected)))

    def test_irregular_layout_uses_contours_and_excludes_header(self):
        deck, expected = make_deck(self.cards, [0, 1, 2, 3, 4, 5, 6, 7],
                                   gap=(20, 28), irregular=True)
        cv2.putText(deck, "DECK LIST", (5, 18), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 0, 0), 1)
        actual, details = detect(deck)
        self.assertEqual(details["method"], "contours")
        self.assertEqual(len(actual), len(expected))
        self.assertTrue(all(max(iou(a, b) for a in actual) > .80 for b in expected))

    def test_manual_grid_gaps_and_roi(self):
        deck, expected = make_deck(self.cards, [0, 1, 2, 3, 4, 5, 6, 7])
        actual, details = detect(deck, roi=(32, 38, 4*70+3*8, 2*98+10), grid=(2, 4), gap=(8, 10))
        self.assertEqual(actual, expected)
        with self.assertRaises(ValueError):
            detect(deck, roi=(-1, 0, 10, 10))

    def test_large_screenshot_maps_boxes_to_original_coordinates(self):
        deck, expected = make_deck(self.cards, [0, 1, 2, 3, 4, 5, 6, 7])
        enlarged = cv2.resize(deck, None, fx=5, fy=5, interpolation=cv2.INTER_NEAREST)
        actual, details = detect(enlarged)
        self.assertLess(details["detection_scale"], 1)
        self.assertEqual(len(actual), len(expected))
        self.assertTrue(all(iou(a, tuple(v*5 for v in b)) > .9 for a, b in zip(actual, expected)))

    def test_full_pipeline_jpeg_counts_and_candidates(self):
        ids = [0, 1, 2, 3, 1, 4, 5]
        deck, _ = make_deck(self.cards, ids)
        path = self.root / "入力.jpg"
        cv2.imencode(".jpg", deck, [cv2.IMWRITE_JPEG_QUALITY, 70])[1].tofile(str(path))
        out = self.root / "result"
        code = main(["--image", str(path), "--data", str(self.data), "--output", str(out),
                     "--cache", str(self.root / "cache"), "--top-k", "3"])
        self.assertEqual(code, 0)
        result = json.loads((out / "results.json").read_text(encoding="utf-8"))
        self.assertEqual([c["final_card_id"] for c in result["cards"]], ["card_{}".format(i) for i in ids])
        self.assertEqual(sum(c["confirmed_count"] for c in result["summary"]["by_file"]), len(ids))
        duplicate = next(c for c in result["summary"]["by_file"] if c["card_id"] == "card_1")
        self.assertEqual(duplicate["confirmed_count"], 2)
        self.assertTrue(all(len(c["candidates"]) == 3 for c in result["cards"]))
        for name in ("report.html", "annotated.png", "cards.csv", "candidates.csv", "summary_cards.csv"):
            self.assertTrue((out / name).is_file())
        self.assertEqual(len(list((out / "crops").glob("*.png"))), len(ids))

    def test_unknown_and_identical_reference_ambiguity(self):
        index = build_index(self.data, self.root / "cache")
        result = match_card(card_image(5555), index)
        self.assertEqual(result["status"], "unknown")
        self.assertIsNone(result["final_file"])
        write_image(self.data / "duplicate.png", self.cards[0])
        index = build_index(self.data, self.root / "cache")
        result = match_card(self.cards[0], index, top_k=1)
        self.assertEqual(result["status"], "ambiguous")
        self.assertIsNone(result["final_file"])
        self.assertEqual(result["margin"], 0)

    def test_metadata_groups_printings_without_resolving_file_tie(self):
        write_image(self.data / "duplicate.png", self.cards[0])
        first = build_index(self.data, self.root / "cache")
        self.assertEqual(match_card(self.cards[0], first)["identity_status"], "ambiguous")
        (self.data / "metadata.csv").write_text(
            "file,card_id,card_name,identity_id\ncard_0.png,print-A,カードA,logical-A\n"
            "duplicate.png,print-B,カードA,logical-A\n", encoding="utf-8-sig")
        second = build_index(self.data, self.root / "cache")
        self.assertNotEqual(first["fingerprint"], second["fingerprint"])
        result = match_card(self.cards[0], second)
        self.assertEqual(result["status"], "ambiguous")
        self.assertEqual(result["identity_status"], "matched")
        self.assertEqual(result["final_identity_id"], "logical-A")
        self.assertEqual(result["final_card_name"], "カードA")

    def test_cache_invalidates_add_modify_remove_and_corrupt_reference(self):
        cache = self.root / "cache"
        first = build_index(self.data, cache)
        self.assertFalse(first["cache_hit"])
        self.assertTrue(build_index(self.data, cache)["cache_hit"])
        write_image(self.data / "new.png", card_image(20))
        second = build_index(self.data, cache)
        self.assertNotEqual(first["fingerprint"], second["fingerprint"])
        write_image(self.data / "new.png", card_image(21))
        third = build_index(self.data, cache)
        self.assertNotEqual(second["fingerprint"], third["fingerprint"])
        (self.data / "new.png").unlink()
        (self.data / "broken.jpg").write_bytes(b"not an image")
        fourth = build_index(self.data, cache)
        self.assertEqual(len(fourth["entries"]), 8)
        self.assertEqual(len(fourth["skipped_files"]), 1)
        self.assertNotEqual(third["fingerprint"], fourth["fingerprint"])

    def test_empty_catalog_blank_image_and_corrupt_input(self):
        with self.assertRaises(ValueError):
            build_index(self.root / "empty", self.root / "cache")
        boxes, _ = detect(np.full((400, 600, 3), 255, np.uint8))
        self.assertEqual(boxes, [])
        bad = self.root / "bad.png"
        bad.write_bytes(b"broken")
        with self.assertRaises(ValueError):
            read_image(bad)

    def test_detect_only_does_not_require_catalog(self):
        deck, _ = make_deck(self.cards, [0, 1, 2, 3, 4, 5, 6, 7])
        path = self.root / "deck.png"
        write_image(path, deck)
        out = self.root / "detect"
        self.assertEqual(main(["--image", str(path), "--detect-only", "--output", str(out)]), 0)
        result = json.loads((out / "results.json").read_text(encoding="utf-8"))
        self.assertIsNone(result["index"])
        self.assertEqual(result["summary"]["detected_count"], 8)


if __name__ == "__main__":
    unittest.main()
